function [ output_args ] = readWithTrackMarks(vr20, index, indexIsAbsolute, forceRGB,)
%READWITHTRACKMARKS Summary of this function goes here
%   Detailed explanation goes here


end

