function [ output_args ] = SupportedFunctions()
output_args = {'MarkSectionStart'};
end