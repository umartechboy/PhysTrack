function videoWriterOpen2(vwo)
    if ~isstruct(vwo)
        open(vwo);
    end
end

