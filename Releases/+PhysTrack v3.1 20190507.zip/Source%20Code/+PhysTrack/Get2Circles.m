function [cen1, rad1, cen2, rad2] = Get2Circles(vro)
% legacy function No particular need in this version
[cen1, rad1] = PhysTrack.Get1Circle(vro);
[cen2, rad2] = PhysTrack.Get1Circle(vro);
end

