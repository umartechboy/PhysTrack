function Label(title_, xlabel_, ylabel_)
title(title_);
xlabel(xlabel_);
ylabel(ylabel_);
end