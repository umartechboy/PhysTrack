function [ output_args ] = KLT2(klt1Handle)
%KLT2 Runs an instance of KLT2 on the current machine after capturing data
%from the remote node
end

