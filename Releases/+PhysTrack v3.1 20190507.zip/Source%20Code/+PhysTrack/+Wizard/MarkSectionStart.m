function MarkSectionStart(title)
% this function does nothing. It is used as a way to tell the wizard maker
% where to begin a section using MarkSectionStart('Section Name') will
% create a section with title 'Section Name' and the code wfollowing this
% function untill the next marker.
end